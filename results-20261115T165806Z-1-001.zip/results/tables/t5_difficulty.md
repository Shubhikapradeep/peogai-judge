**Results by problem difficulty (50 pairs per level)**

| Model | Difficulty | Exp 1 acc | Exp 1 consistency | Exp 3 acc | Exp 3 FAR |
|---|---|---|---|---|---|
| Qwen2.5-Coder-3B | easy | 53.0 | 6.0 | 57.0 | 68.0 |
|  | medium | 53.0 | 10.0 | 49.0 | 84.0 |
|  | hard | 52.0 | 8.0 | 53.0 | 76.0 |
| Qwen2.5-Coder-7B (4-bit) | easy | 57.0 | 14.0 | 58.0 | 70.0 |
|  | medium | 55.0 | 18.0 | 58.0 | 72.0 |
|  | hard | 51.0 | 14.0 | 53.0 | 74.0 |

_Values in %. Difficulty labels come from CodeJudgeBench and are noisy: the same problem often has different labels in different splits._
