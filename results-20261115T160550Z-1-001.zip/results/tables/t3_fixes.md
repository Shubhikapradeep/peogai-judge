**Exp 4: position-bias fixes compared with the baseline**

| Model | Method | Accuracy | Consistency | % A verdicts | Coverage | p vs baseline |
|---|---|---|---|---|---|---|
| Qwen2.5-Coder-3B | Baseline (Exp 1) | 53.7 | 11.3 | 94.3 | 100.0 | -- |
|  | Order averaging (4a) | 82.4 | 100.0 | -- | 11.3 | -- |
|  | Debias prompt (4b) | 51.7 | 3.3 | 98.3 | 100.0 | 0.263 |
|  | Majority of 3 (4c) | 50.3 | 8.7 | 65.7 | 100.0 | 0.378 |
| Qwen2.5-Coder-7B (4-bit) | Baseline (Exp 1) | 53.0 | 19.3 | 90.3 | 100.0 | -- |
|  | Order averaging (4a) | 65.5 | 100.0 | -- | 19.3 | -- |
|  | Debias prompt (4b) | 53.0 | 11.3 | 93.7 | 100.0 | 1.000 |

_Values in %. 4a accuracy is on decided pairs only; coverage = % of pairs decided. p: exact McNemar test on per-call correctness vs Exp 1._
